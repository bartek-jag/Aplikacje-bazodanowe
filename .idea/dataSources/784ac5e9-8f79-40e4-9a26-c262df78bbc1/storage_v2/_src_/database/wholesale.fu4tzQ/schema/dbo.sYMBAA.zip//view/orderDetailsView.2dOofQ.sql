CREATE VIEW orderDetailsView AS
SELECT oorder.id, beverageName.name, beverageType.beverageType, flavor.flavor, gasType.gasType, package.packageType, orderDetails.quantity, beverage.price, beverage.price*orderDetails.quantity AS [total price]
FROM orderDetails 
	INNER JOIN oorder ON orderDetails.oorderId = oorder.id
	INNER JOIN beverage ON orderDetails.beverageId = beverage.id
	INNER JOIN beverageName ON beverage.beverageNameId = beverageName.id
	INNER JOIN beverageType ON beverage.beverageTypeId = beverageType.id
	LEFT JOIN flavor ON beverage.flavorId = flavor.id
	LEFT JOIN gasType ON beverage.gasTypeId = gasType.id
	LEFT JOIN package ON beverage.packageId = package.id
go

