CREATE VIEW ordersView AS
SELECT oorder.id, customer.firstName, customer.lastName, oorder.orderDate
FROM oorder
	INNER JOIN customer ON oorder.customerId = customer.id
go

